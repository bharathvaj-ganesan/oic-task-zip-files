## Sample NodeApp

---

To install the dependencies

> yarn or npm install

To run

> npm start
