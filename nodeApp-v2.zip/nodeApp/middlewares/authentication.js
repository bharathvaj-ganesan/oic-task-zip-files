module.exports = (req, res, next) => {
	if (req.session.accessToken) {
		next();
	} else {
		req.flash({
			type: 'error',
			message: 'Please login to continue',
			redirect: '/'
		});
	}
};
