const router = require('express').Router();
const passport = require('passport');
const axios = require('axios');
const authMiddleware = require('../middlewares/authentication');

/* GET login page. */
router.get('/', (req, res, next) => {
	res.render('index', {});
});

router.get('/home', authMiddleware, (req, res, next) => {
	res.render('home', {
		userEmail: req.session.userEmail,
		userName: req.session.userName
	});
});

router.get('/auth/logout', authMiddleware, (req, res, next) => {
	req.session = null;
	res.redirect('/');
});

router.get(
	'/auth/google',
	passport.authenticate('google', {
		scope: ['profile', 'email']
	})
);

router.get(
	'/auth/google/callback',
	passport.authenticate('google', {
		session: false,
		failureRedirect: '/'
	}),
	(req, res) => {
		req.session.accessToken = req.user.accessToken;
		req.session.userName = req.user.profile.displayName;
		req.session.userEmail = req.user.profile.emails[0].value;
		res.redirect('/home');
	}
);

router.get('/img', (req, res) => {
	axios
		.get(req.query.url, {
			responseType: 'arraybuffer'
		})
		.then(function(response) {
			res.send(Buffer.from(response.data, 'binary').toString('base64'));
		})
		.catch(function(error) {
			res.send('Something went wrong');
		});
});

module.exports = router;
