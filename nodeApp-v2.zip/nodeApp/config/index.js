module.exports = {
	GOOGLE_CLIENT_KEY: process.env.GOOGLE_CLIENT_KEY,
	GOOGLE_SECRET_KEY: process.env.GOOGLE_SECRET_KEY,
	SERVER_URL: process.env.SERVER_URL,
	AUTH_COOKIE: {
		SECRET: process.env.AUTH_COOKIE_SECRET,
		MAX_AGE: process.env.AUTH_COOKIE_MAX_AGE,
		NAME: process.env.AUTH_COOKIE_NAME
	}
};
