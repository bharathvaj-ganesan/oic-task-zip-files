const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const config = require('../config');
passport.use(
	new GoogleStrategy(
		{
			clientID: config.GOOGLE_CLIENT_KEY,
			clientSecret: config.GOOGLE_SECRET_KEY,
			callbackURL: `${config.SERVER_URL}/auth/google/callback`
		},
		(accessToken, refreshToken, profile, done) => {
			return done(null, {
				profile: profile,
				accessToken: accessToken
			});
		}
	)
);
