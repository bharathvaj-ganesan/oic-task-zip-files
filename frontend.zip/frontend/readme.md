## Front End Task

---

1.  I used **canvas** since it was allowed to be used at the cost of browser security error.(Same origin error)
2.  There is a simple hack which we can use it to bypass this issue (performance issue)
